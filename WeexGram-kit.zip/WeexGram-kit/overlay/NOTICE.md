# Источники и лицензии

- **NimarkoGram**, Ettacent и участники: https://github.com/Ettacent/NimarkoGram, base `0f1c6aa243d8509339f528f35887b6d91d051a03`. GPL, файл LICENSE приложен без изменений. Авторские уведомления в исходных файлах сохранены.
- **Telegram for Android**, Nikolai Kudashov и участники: исходный код Telegram, на котором основан NimarkoGram. Исходный Java namespace и исходный движок воспроизведения сохранены.
- **WeexMD3 3.21.0**, автор из метаданных файла — `@crezany`. Legacy-файл включён по вашему выбору без изменения содержимого. Это отдельно распространяемый внешний вариант, не исполняемая часть нативного модуля. Перед публичным распространением подтвердите права на его включение; заголовок файла не задаёт отдельную явную лицензию.
- **Material Symbols Rounded**, Google: https://github.com/google/material-design-icons. Векторы скачаны из `symbols/android/<name>/materialsymbolsrounded/<name>_24px.xml`. Apache License 2.0 включена в `assets/weexgram/MATERIAL_SYMBOLS_LICENSE.txt`.
- **Material Components for Android**: зависимость `com.google.android.material:material:1.13.0` уже присутствует в NimarkoGram; отдельные бинарники библиотеки в комплект не добавляются.
- **LRCLIB**: https://lrclib.net/docs. Используются read-only `/api/get` и `/api/search`, без публикации текстов. Тексты не включены в APK/архив и загружаются только после разрешения пользователя. Клиент поддерживает User-Agent, последовательные запросы и Retry-After. Перед публичным выпуском замените ссылку базового проекта в User-Agent на homepage своего форка.
- Код Opexgram не использовался. Реализована самостоятельная приближённая версия progressive blur и движения для новых Weex-поверхностей; идентичность Opexgram не заявляется.

Новые Kotlin-модули предоставлены с SPDX GPL-2.0-or-later. Наличие этого уведомления не отменяет лицензии базового проекта, внешнего legacy-плагина и отдельных ресурсов. При распространении APK предоставляйте соответствующие исходники, build scripts и уведомления; не выдавайте WeexGram за официальный Telegram/NimarkoGram.


## Marblegram (GPLv2)
Файлы `org/telegram/marble/MaterialShapes.java`, `MarbleShapeDrawable.java`, `LoadingIndicator.java` взяты из https://github.com/Artyom151/marblegram (лицензия GPL-2.0, см. LICENSE). Заголовки файлов сохранены.
