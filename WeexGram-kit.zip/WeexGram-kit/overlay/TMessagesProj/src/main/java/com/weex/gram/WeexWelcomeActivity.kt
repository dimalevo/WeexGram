// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ScrollView
import android.widget.Toast
import java.util.concurrent.Executors

/** Explicit opt-in choice. The bundled Python file is exported via SAF, never auto-executed. */
class WeexWelcomeActivity:Activity(){
    private val io=Executors.newSingleThreadExecutor()
    private var writing=false
    override fun attachBaseContext(base:Context){super.attachBaseContext(WeexConfig.themed(base))}
    override fun onCreate(state:Bundle?){
        super.onCreate(state)
        val ui=SettingsUI(this);val content=ui.column().apply{setPadding(ui.dp(24),ui.dp(48),ui.dp(24),ui.dp(32))}
        content.addView(ui.label("Добро пожаловать в WeexGram",28f))
        content.addView(ui.label("Независимый форк NimarkoGram. Telegram и NimarkoGram не являются авторами этой сборки.",16f,true))
        val info=ui.card(content)
        info.addView(ui.label("WeexMD3 внутри приложения",20f))
        info.addView(ui.label("Плеер, оформление и тексты песен работают через нативный код. Python-плагин для этого не нужен. Поиск LRCLIB выключен до вашего согласия.",14f,true))
        ui.button(content,"Использовать встроенную версию"){WeexConfig.player=true;WeexConfig.welcomed=true;finish()}
        ui.button(content,"Скачать WeexMD3 плагин",org.telegram.messenger.R.drawable.weexgram_download){
            if(!writing)startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(Intent.CATEGORY_OPENABLE);type="application/octet-stream";putExtra(Intent.EXTRA_TITLE,"WeexMD3_3_21_0.plugin")},721)
        }
        content.addView(ui.label("Сохранение плагина отключит встроенный плеер. Установите сохранённый файл вручную в разделе плагинов NimarkoGram. Само сохранение ничего не запускает.",14f,true))
        setContentView(ScrollView(this).apply{setBackgroundColor(ui.surface);addView(content)})
    }
    @Deprecated("Compatibility")
    override fun onActivityResult(request:Int,result:Int,data:Intent?){
        super.onActivityResult(request,result,data)
        if(request!=721 || result!=RESULT_OK)return
        val uri=data?.data ?: return
        writing=true
        io.execute{
            val success=runCatching {assets.open("weexgram/WeexMD3_3_21_0.plugin").use{input->contentResolver.openOutputStream(uri,"wt")?.use{output->input.copyTo(output)} ?: error("Не удалось открыть файл")}}
            runOnUiThread{
                writing=false
                if(!isFinishing && !isDestroyed)success.fold({WeexConfig.player=false;WeexConfig.welcomed=true;Toast.makeText(this,"Плагин сохранён. Установите его вручную в разделе плагинов.",Toast.LENGTH_LONG).show();finish()}, {Toast.makeText(this,"Ошибка сохранения: ${it.message}",Toast.LENGTH_LONG).show()})
            }
        }
    }
    @Deprecated("Compatibility")
    override fun onBackPressed(){if(!writing){WeexConfig.welcomed=true;super.onBackPressed()}}
    override fun onDestroy(){io.shutdown();super.onDestroy()}
}
