// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import org.telegram.messenger.MessagesController
import org.telegram.messenger.SharedConfig
import org.telegram.ui.ActionBar.Theme

/**
 * Пишет те же ключи, что и экран «Тема» в Telegram (ThemeActivity.setBubbleRadius / setFontSize).
 * Значения действуют во всём Telegram. Открытые чаты обновятся после переоткрытия.
 */
object WeexChatStyle {
    const val BUBBLE_MIN = 0
    const val BUBBLE_MAX = 17
    const val FONT_MIN = 12
    const val FONT_MAX = 30

    fun setBubbleRadius(value: Int) {
        val v = value.coerceIn(BUBBLE_MIN, BUBBLE_MAX)
        SharedConfig.bubbleRadius = v
        MessagesController.getGlobalMainSettings().edit().putInt("bubbleRadius", v).apply()
    }

    fun setFontSize(value: Int) {
        val v = value.coerceIn(FONT_MIN, FONT_MAX)
        SharedConfig.fontSize = v
        SharedConfig.fontSizeIsDefault = false
        MessagesController.getGlobalMainSettings().edit().putInt("fons_size", v).apply()
        Theme.createCommonMessageResources()
    }
}
