// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import com.google.android.material.button.MaterialButton
import org.telegram.messenger.AndroidUtilities
import org.telegram.messenger.MediaController
import org.telegram.messenger.MessageObject
import org.telegram.messenger.R
import org.telegram.ui.ActionBar.BottomSheet
import org.telegram.ui.ActionBar.Theme
import org.telegram.ui.Components.AudioPlayerAlert

/** Native player core port. Uses Telegram's existing controller, service, queue and media session. */
class Sheet(private val host:Context,provider:Theme.ResourcesProvider?):BottomSheet(host,false,provider){
    private val ui=SettingsUI(WeexConfig.themed(host))
    private val media=MediaController.getInstance()
    private val handler=Handler(Looper.getMainLooper())
    private val repository=LyricsRepository()
    private val panel=ui.column()
    private val backdrop=ProgressiveBlurBackdrop(host)
    private val cover=ImageView(ui.context)
    private val title=ui.label("Сейчас играет",22f)
    private val artist=ui.label("",14f,true)
    private val time=ui.label("0:00 / 0:00",14f,true)
    private val seek=SeekBar(ui.context)
    private lateinit var play:MaterialButton
    private val lyricsScroll=ScrollView(ui.context)
    private val karaoke=KaraokeView(ui.context,ui)
    private val status=ui.label("",14f,true)
    private val controls=ArrayList<View>()
    private var alive=true
    private var dragging=false
    private var trackKey=""
    private var lyricMode=false
    private var lyricsLoaded=false
    private var owner:android.app.Activity?=null
    private val ownerLifecycle=object:android.app.Application.ActivityLifecycleCallbacks {
        override fun onActivityStopped(activity:android.app.Activity){if(activity===owner){handler.removeCallbacks(ticker);repository.cancel();backdrop.release()}}
        override fun onActivityStarted(activity:android.app.Activity){if(activity===owner && alive && isShowing){handler.removeCallbacks(ticker);handler.post(ticker);if(lyricMode && !lyricsLoaded && WeexConfig.lyrics)media.playingMessageObject?.let{loadLyrics(it)}}}
        override fun onActivityDestroyed(activity:android.app.Activity){if(activity===owner)cleanup()}
        override fun onActivityCreated(activity:android.app.Activity,state:android.os.Bundle?){}
        override fun onActivityResumed(activity:android.app.Activity){}
        override fun onActivityPaused(activity:android.app.Activity){}
        override fun onActivitySaveInstanceState(activity:android.app.Activity,state:android.os.Bundle){}
    }
    private val ticker=object:Runnable{override fun run(){if(alive && isShowing){refresh();handler.postDelayed(this,150)}}}
    init {
        val frame=FrameLayout(host).apply{background=ui.rounded(ui.surface);clipToOutline=true}
        frame.addView(backdrop,FrameLayout.LayoutParams(-1,-1))
        panel.setPadding(ui.dp(24),ui.dp(20),ui.dp(24),ui.dp(20))
        panel.setBackgroundColor(if(WeexConfig.blur)(ui.surface and 0xffffff) or (215 shl 24) else ui.surface)
        val header=LinearLayout(ui.context).apply{gravity=Gravity.CENTER_VERTICAL}
        header.addView(ui.label("WeexGram",18f),LinearLayout.LayoutParams(0,-2,1f))
        header.addView(icon(R.drawable.weexgram_settings,"Настройки"){menu()});header.addView(icon(R.drawable.weexgram_close,"Закрыть"){dismiss()})
        panel.addView(header)
        cover.scaleType=ImageView.ScaleType.CENTER_CROP;cover.background=ui.rounded(ui.high,if(WeexConfig.design)28 else 8);cover.clipToOutline=true
        panel.addView(cover,LinearLayout.LayoutParams(ui.dp(128),ui.dp(128)).apply{gravity=Gravity.CENTER_HORIZONTAL;topMargin=ui.dp(12)})
        title.maxLines=2;title.gravity=Gravity.CENTER;artist.gravity=Gravity.CENTER
        panel.addView(title,LinearLayout.LayoutParams(-1,-2));panel.addView(artist,LinearLayout.LayoutParams(-1,-2))
        panel.addView(seek,LinearLayout.LayoutParams(-1,ui.dp(48)));panel.addView(time)
        seek.max=1000;seek.contentDescription="Позиция воспроизведения"
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(bar:SeekBar?,progress:Int,user:Boolean){}
            override fun onStartTrackingTouch(bar:SeekBar?){dragging=true}
            override fun onStopTrackingTouch(bar:SeekBar?){media.playingMessageObject?.let{media.seekToProgress(it,seek.progress/1000f)};dragging=false}
        })
        val transport=LinearLayout(ui.context).apply{gravity=Gravity.CENTER}
        transport.addView(icon(R.drawable.weexgram_skip_previous,"Предыдущий"){media.playPreviousMessage()})
        play=icon(R.drawable.weexgram_play_arrow,"Воспроизвести"){media.playingMessageObject?.let{if(media.isMessagePaused)media.playMessage(it)else media.pauseMessage(it)}}
        transport.addView(play);transport.addView(icon(R.drawable.weexgram_skip_next,"Следующий"){media.playNextMessage()});panel.addView(transport)
        val lyrics=ui.button(panel,"Текст песни · LRCLIB",R.drawable.weexgram_lyrics){toggleLyrics()};controls.add(lyrics)
        lyricsScroll.addView(karaoke,FrameLayout.LayoutParams(-1,-2));lyricsScroll.visibility=View.GONE
        panel.addView(lyricsScroll,LinearLayout.LayoutParams(-1,ui.dp(220)));panel.addView(status)
        karaoke.onActiveLine={top->if(WeexMotion.enabled())lyricsScroll.smoothScrollTo(0,(top-ui.dp(80)).coerceAtLeast(0))else lyricsScroll.scrollTo(0,(top-ui.dp(80)).coerceAtLeast(0))}
        frame.addView(panel,FrameLayout.LayoutParams(-1,-2));setCustomView(frame)
    }
    private fun icon(drawable:Int,description:String,action:()->Unit):MaterialButton {
        return MaterialButton(ui.context).apply{
            text="";setIconResource(drawable);iconGravity=MaterialButton.ICON_GRAVITY_TEXT_START;iconPadding=0;insetTop=ui.dp(4);insetBottom=ui.dp(4)
            setPadding(ui.dp(12),0,ui.dp(12),0);minimumWidth=ui.dp(56);minimumHeight=ui.dp(56);contentDescription=description
            layoutParams=LinearLayout.LayoutParams(ui.dp(64),ui.dp(56))
            setOnClickListener{action();refresh()}
            setOnTouchListener{v,e->when(e.actionMasked){MotionEvent.ACTION_DOWN->WeexMotion.press(v,true);MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->WeexMotion.press(v,false)};false}
            controls.add(this)
        }
    }
    override fun show(){
        if(isShowing || !alive)return
        super.show()
        owner=AndroidUtilities.findActivity(host)
        owner?.let{it.application.registerActivityLifecycleCallbacks(ownerLifecycle);backdrop.capture(it)}
        WeexMotion.enter(panel);handler.post(ticker)
    }
    private fun refresh(){
        if(!WeexConfig.lyrics && lyricMode){repository.cancel();lyricMode=false;lyricsLoaded=false;lyricsScroll.visibility=View.GONE;cover.visibility=View.VISIBLE;status.text="Тексты отключены"}
        val track=media.playingMessageObject
        if(track==null || !track.isMusic){if(trackKey.isNotEmpty()){trackKey="";repository.cancel()};lyricsLoaded=false;title.text="Нет музыкального трека";seek.isEnabled=false;play.isEnabled=false;return}
        play.isEnabled=true
        val key="${track.currentAccount}:${track.dialogId}:${track.id}"
        if(key!=trackKey){
            trackKey=key;repository.cancel();lyricsLoaded=false;karaoke.setLyrics(emptyList(),0);status.text=""
            title.text=track.musicTitle;artist.text=track.musicAuthor
            val bitmap=media.audioInfo?.cover
            if(bitmap!=null)cover.setImageBitmap(bitmap)else cover.setImageResource(R.drawable.weexgram_music_note)
            if(lyricMode && WeexConfig.lyrics)loadLyrics(track)
        }
        seek.isEnabled=true
        if(!dragging)seek.progress=(track.audioProgress*1000).toInt().coerceIn(0,1000)
        time.text="${clock(track.audioProgressSec)} / ${clock(track.duration.toInt())}"
        play.setIconResource(if(media.isMessagePaused)R.drawable.weexgram_play_arrow else R.drawable.weexgram_pause)
        play.contentDescription=if(media.isMessagePaused)"Воспроизвести" else "Пауза"
        if(lyricMode && lyricsLoaded)karaoke.position((track.audioProgress*track.duration*1000).toLong())
    }
    private fun toggleLyrics(){
        if(!WeexConfig.lyrics){
            com.google.android.material.dialog.MaterialAlertDialogBuilder(ui.context).setTitle("Поиск текстов")
                .setMessage("Отправлять исполнителя, название и длительность текущего трека на lrclib.net? Сообщения, файлы и данные Telegram не отправляются.")
                .setPositiveButton("Разрешить"){_,_->WeexConfig.lyrics=true;showLyrics()}.setNegativeButton("Отмена",null).show();return
        }
        if(lyricMode){lyricMode=false;cover.visibility=View.VISIBLE;lyricsScroll.visibility=View.GONE;status.visibility=View.GONE}
        else showLyrics()
    }
    private fun showLyrics(){lyricMode=true;cover.visibility=View.GONE;lyricsScroll.visibility=View.VISIBLE;status.visibility=View.VISIBLE;media.playingMessageObject?.let{loadLyrics(it)}}
    private fun loadLyrics(track:MessageObject){
        val key=trackKey;status.text="Ищем в LRCLIB…";lyricsLoaded=false
        repository.load(track.musicAuthor,track.musicTitle,track.duration.toInt()){result->
            if(alive && key==trackKey && WeexConfig.lyrics)result.fold({lyrics->
                lyricsLoaded=lyrics.lines.isNotEmpty();karaoke.setLyrics(lyrics.lines,(track.duration*1000).toLong())
                status.text=when{lyrics.instrumental->"Инструментальная композиция";lyricsLoaded->"LRCLIB · синхронизация по строкам; заполнение строки приблизительное";lyrics.plain.isNotBlank()->lyrics.plain.take(30000);else->"Текст не найден"}
            },{error->status.text=error.message ?: "Не удалось загрузить текст"})
        }
    }
    private fun menu(){
        val menu=BottomSheet(host,false);val content=ui.column().apply{setPadding(ui.dp(24),ui.dp(24),ui.dp(24),ui.dp(24));setBackgroundColor(ui.surface)}
        content.addView(ui.label("Плеер WeexGram",22f))
        ui.button(content,"Очередь воспроизведения",R.drawable.weexgram_queue_music){menu.dismiss();queue()}
        ui.button(content,"Настройки дизайна MD3",R.drawable.weexgram_settings){menu.dismiss();val fragment=org.telegram.ui.LaunchActivity.getSafeLastFragment();fragment?.presentFragment(WeexSettingsFragment())}
        ui.button(content,"Открыть штатный плеер"){menu.dismiss();dismiss();AudioPlayerAlert(host,null).show()}
        menu.setCustomView(menuSurface(content));menu.show();WeexMotion.enter(content)
    }
    private fun queue(){
        val menu=BottomSheet(host,false);val content=ui.column();val scroll=ScrollView(ui.context)
        content.setPadding(ui.dp(24),ui.dp(16),ui.dp(24),ui.dp(16));content.setBackgroundColor(ui.surface)
        content.addView(ui.label("Очередь · первые 50 треков",20f))
        media.playlist.take(50).forEach{track->ui.button(content,"${track.musicTitle} — ${track.musicAuthor}"){media.playMessage(track);menu.dismiss();refresh()}}
        scroll.addView(content);menu.setCustomView(menuSurface(scroll));menu.show()
    }
    private fun menuSurface(content:View):View {
        if(!WeexConfig.blur || android.os.Build.VERSION.SDK_INT<31)return content
        val blur=ProgressiveBlurBackdrop(host)
        AndroidUtilities.findActivity(host)?.let{blur.capture(it)}
        val frame=FrameLayout(host).apply{background=ui.rounded(ui.surface);clipToOutline=true}
        frame.addView(blur,FrameLayout.LayoutParams(-1,-1))
        content.setBackgroundColor((ui.surface and 0xffffff) or (215 shl 24))
        frame.addView(content,FrameLayout.LayoutParams(-1,-2));return frame
    }
    private fun cleanup(){if(!alive)return;alive=false;owner?.application?.unregisterActivityLifecycleCallbacks(ownerLifecycle);owner=null;handler.removeCallbacksAndMessages(null);repository.close();controls.forEach{WeexMotion.stop(it)};WeexMotion.stop(panel);backdrop.release();cover.setImageDrawable(null)}
    override fun dismiss(){cleanup();super.dismiss()}
    override fun dismissInternal(){cleanup();super.dismissInternal()}
    private fun clock(seconds:Int)="${seconds.coerceAtLeast(0)/60}:${(seconds.coerceAtLeast(0)%60).toString().padStart(2,'0')}"
}
