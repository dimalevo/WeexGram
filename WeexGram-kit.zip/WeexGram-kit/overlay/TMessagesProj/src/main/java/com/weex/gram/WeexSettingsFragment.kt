// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.ScrollView
import org.telegram.messenger.R
import org.telegram.ui.ActionBar.ActionBar
import org.telegram.ui.ActionBar.BaseFragment

class WeexSettingsFragment:BaseFragment(){
    override fun createView(context:Context):View {
        actionBar.setTitle("WeexGram")
        actionBar.setBackButtonImage(R.drawable.weexgram_arrow_back)
        actionBar.setActionBarMenuOnItemClick(object:ActionBar.ActionBarMenuOnItemClick(){override fun onItemClick(id:Int){if(id == -1)finishFragment()}})
        val ui=SettingsUI(WeexConfig.themed(context));val content=ui.column().apply{setPadding(ui.dp(20),ui.dp(16),ui.dp(20),ui.dp(32))}
        val scroll=ScrollView(ui.context).apply{setBackgroundColor(ui.surface);addView(content)}
        content.addView(ui.label("WeexGram · встроенный WeexMD3",24f))
        content.addView(ui.label("Нативное ядро на Kotlin. Настройки сохраняются сразу.",14f,true))
        ui.toggle(content,"Включить MD3 Плеер","Использовать встроенную музыкальную шторку вместо AudioPlayerAlert",WeexConfig.player){WeexConfig.player=it}
        ui.toggle(content,"Настройки дизайна MD3","Крупные карточки и скругления WeexGram",WeexConfig.design){WeexConfig.design=it}
        ui.toggle(content,"Анимации","Переходы PathInterpolator и физические пружины кнопок",WeexConfig.animations){WeexConfig.animations=it}
        ui.toggle(content,"Progressive Blur","Подложка плеера на Android 12+. По умолчанию выключено; защищённые окна не захватываются.",WeexConfig.blur){WeexConfig.blur=it}
        ui.toggle(content,"Тексты LRCLIB","Разрешить передачу исполнителя, названия и длительности на lrclib.net",WeexConfig.lyrics){WeexConfig.lyrics=it}

        // Порция 1: оформление в стиле клавиатуры WeexMD3 2.20.30.
        content.addView(ui.label("Оформление (Material You)",18f))
        ui.choice(content,"Палитра",listOf("Системная","Светлая","Тёмная"),WeexConfig.palette){WeexConfig.palette=it}
        ui.toggle(content,"Monet","Цвет акцента из обоев (Android 12+). Выключено — палитра клавиатуры.",WeexConfig.monet){WeexConfig.monet=it}
        ui.swatches(content,"Цвет акцента",12,WeexConfig.accent){WeexConfig.accent=it}
        ui.slider(content,"Контраст текста",0f,1f,0.1f,WeexConfig.contrast,{String.format("%d%%",(it*100).toInt())}){WeexConfig.contrast=it}
        ui.toggle(content,"AMOLED","Чёрный фон в тёмной палитре",WeexConfig.amoled){WeexConfig.amoled=it}

        // Порция 1: движение (M3 Expressive / Standard, пружины из compose material3).
        content.addView(ui.label("Движение",18f))
        ui.choice(content,"Схема движения",listOf("Стандартная","Выразительная"),WeexConfig.motionScheme){WeexConfig.motionScheme=it}
        ui.slider(content,"Скорость анимаций",0.5f,2f,0.1f,WeexConfig.motionSpeed,{String.format("%.1f×",it)}){WeexConfig.motionSpeed=it}
        ui.toggle(content,"Эффект нажатия","Пружина при нажатии на кнопки и карточки",WeexConfig.pressSpring){WeexConfig.pressSpring=it}
        ui.toggle(content,"Появление элементов","Плавный сдвиг и затухание при открытии экрана",WeexConfig.enterAnimation){WeexConfig.enterAnimation=it}
        ui.toggle(content,"Уменьшить движение","Отключает все анимации WeexGram, как системная настройка",WeexConfig.reduceMotion){WeexConfig.reduceMotion=it}

        ui.button(content,"Скачать WeexMD3 плагин",R.drawable.weexgram_download){context.startActivity(Intent(context,WeexWelcomeActivity::class.java))}
        content.addView(ui.label("Внешний плагин не нужен для встроенного плеера. При его выборе встроенная версия отключается. После смены дизайна переоткройте этот экран/плеер.",14f,true))
        fragmentView=scroll;return scroll
    }
}
