// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import app.nimarkogram.messenger.AppConfig
import org.telegram.messenger.R
import org.telegram.messenger.SharedConfig
import org.telegram.ui.ActionBar.ActionBar
import org.telegram.ui.ActionBar.BaseFragment

class WeexSettingsFragment:BaseFragment(){
    override fun createView(context:Context):View {
        actionBar.setTitle("Настройки WeexGram")
        actionBar.setBackButtonImage(R.drawable.weexgram_arrow_back)
        actionBar.setActionBarMenuOnItemClick(object:ActionBar.ActionBarMenuOnItemClick(){override fun onItemClick(id:Int){if(id == -1)finishFragment()}})
        val ui=SettingsUI(WeexConfig.themed(context));val content=ui.column().apply{setPadding(ui.dp(20),ui.dp(16),ui.dp(20),ui.dp(32))}
        val scroll=ScrollView(ui.context).apply{setBackgroundColor(ui.surface);addView(content)}
        content.addView(ui.label("Настройки WeexGram",24f))
        // Значок WeexGram: та же иконка, что у клавиатуры WeexMD3.
        content.addView(android.widget.ImageView(context).apply{setImageResource(R.drawable.weexgram_brand)},
            LinearLayout.LayoutParams(ui.dp(56),ui.dp(56)).apply{bottomMargin=ui.dp(8)})
        content.addView(ui.label("Нативное ядро на Kotlin. Настройки сохраняются сразу.",14f,true))
        ui.toggle(content,"Включить MD3 Плеер","Использовать встроенную музыкальную шторку вместо AudioPlayerAlert",WeexConfig.player){WeexConfig.player=it}
        ui.toggle(content,"Настройки дизайна MD3","Крупные карточки и скругления WeexGram",WeexConfig.design){WeexConfig.design=it}
        ui.toggle(content,"Анимации","Переходы PathInterpolator и физические пружины кнопок",WeexConfig.animations){WeexConfig.animations=it}
        ui.toggle(content,"Progressive Blur","Подложка плеера на Android 12+. По умолчанию выключено; защищённые окна не захватываются.",WeexConfig.blur){WeexConfig.blur=it}
        ui.toggle(content,"Тексты LRCLIB","Разрешить передачу исполнителя, названия и длительности на lrclib.net",WeexConfig.lyrics){WeexConfig.lyrics=it}

        // Порция 1: оформление в стиле клавиатуры WeexMD3 2.20.30.
        content.addView(ui.label("Оформление (Material You)",18f))
        ui.choice(content,"Палитра",listOf("Системная","Светлая","Тёмная"),WeexConfig.palette){WeexConfig.palette=it}
        ui.toggle(content,"Monet","Цвет акцента из обоев (Android 12+). Выключено — палитра клавиатуры.",WeexConfig.monet){WeexConfig.monet=it}
        ui.swatches(content,"Цвет акцента",12,WeexConfig.accent){WeexConfig.accent=it}
        ui.slider(content,"Контраст текста",0f,1f,0.1f,WeexConfig.contrast,{String.format("%d%%",(it*100).toInt())}){WeexConfig.contrast=it}
        ui.toggle(content,"AMOLED","Чёрный фон в тёмной палитре",WeexConfig.amoled){WeexConfig.amoled=it}

        // Порция 1: движение (M3 Expressive / Standard, пружины из compose material3).
        content.addView(ui.label("Движение",18f))
        ui.choice(content,"Схема движения",listOf("Стандартная","Выразительная"),WeexConfig.motionScheme){WeexConfig.motionScheme=it}
        ui.slider(content,"Скорость анимаций",0.5f,2f,0.1f,WeexConfig.motionSpeed,{String.format("%.1f×",it)}){WeexConfig.motionSpeed=it}
        ui.toggle(content,"Эффект нажатия","Пружина при нажатии на кнопки и карточки",WeexConfig.pressSpring){WeexConfig.pressSpring=it}
        ui.toggle(content,"Появление элементов","Плавный сдвиг и затухание при открытии экрана",WeexConfig.enterAnimation){WeexConfig.enterAnimation=it}
        ui.toggle(content,"Уменьшить движение","Отключает все анимации WeexGram, как системная настройка",WeexConfig.reduceMotion){WeexConfig.reduceMotion=it}

        // Порция 2: пузыри и шрифт чата. Пишут ключи Telegram (ThemeActivity), действуют во всём приложении.
        content.addView(ui.label("Чат",18f))
        ui.slider(content,"Скругление пузырей",WeexChatStyle.BUBBLE_MIN.toFloat(),WeexChatStyle.BUBBLE_MAX.toFloat(),1f,SharedConfig.bubbleRadius.toFloat(),{String.format("%d dp",it.toInt())}){WeexChatStyle.setBubbleRadius(it.toInt())}
        ui.slider(content,"Размер шрифта сообщений",WeexChatStyle.FONT_MIN.toFloat(),WeexChatStyle.FONT_MAX.toFloat(),1f,SharedConfig.fontSize.toFloat(),{String.format("%d sp",it.toInt())}){WeexChatStyle.setFontSize(it.toInt())}

        // Порция 3: флаги, которые уже есть в базе NimarkoGram (AppConfig). Меняем только при расхождении.
        content.addView(ui.label("Из базы NimarkoGram",18f))
        ui.toggle(content,"ID и DC в профиле","Показывать идентификатор и дата-центр",AppConfig.showIDDC){if(it!=AppConfig.showIDDC)AppConfig.toggleShowIDDC()}
        ui.toggle(content,"Заголовок чата по центру","Название чата в центре шапки",AppConfig.centerTitle){if(it!=AppConfig.centerTitle)AppConfig.toggleCenterTitle()}
        ui.toggle(content,"Папки внизу экрана","Панель папок снизу, как в клавиатуре",AppConfig.foldersAtBottom){if(it!=AppConfig.foldersAtBottom)AppConfig.toggleFoldersAtBottom()}
        ui.toggle(content,"Отключить вибрацию в чатах","Без тактильного отклика при действиях",AppConfig.disableVibration){if(it!=AppConfig.disableVibration)AppConfig.toggleDisableVibration()}
        ui.toggle(content,"Предиктивный жест назад","Анимация возврата при свайпе назад",AppConfig.predictiveBack){if(it!=AppConfig.predictiveBack)AppConfig.togglePredictiveBack()}
        ui.toggle(content,"Свои обои в чатах","Использовать обои из настроек базы",AppConfig.customWallpapers){if(it!=AppConfig.customWallpapers)AppConfig.toggleCustomWallpapers()}
        ui.toggle(content,"Скрыть истории","Не показывать блок историй",AppConfig.hideStories){if(it!=AppConfig.hideStories)AppConfig.toggleHideStories()}
        ui.toggle(content,"Показывать аккаунты","Переключение между аккаунтами",AppConfig.showAccounts){if(it!=AppConfig.showAccounts)AppConfig.toggleShowAccounts()}
        ui.toggle(content,"Скрыть время на стикерах","Убрать время отправки со стикеров",AppConfig.hideStickerTime){if(it!=AppConfig.hideStickerTime)AppConfig.toggleHideStickerTime()}

        // Порция 4: ещё флаги базы NimarkoGram (без Premium).
        ui.toggle(content,"Крупные фото","Фото в ленте занимают больше места",AppConfig.largePhotos){if(it!=AppConfig.largePhotos)AppConfig.toggleLargePhotos()}
        ui.toggle(content,"Скрыть кнопку «без звука»","Убрать кнопку выключения звука в чате",AppConfig.hideMuteUnmuteButton){if(it!=AppConfig.hideMuteUnmuteButton)AppConfig.toggleHideMuteUnmuteButton()}
        ui.toggle(content,"Автопауза видео","Останавливать видео, когда оно уходит с экрана",AppConfig.autoPauseVideo){if(it!=AppConfig.autoPauseVideo)AppConfig.toggleAutoPauseVideo()}
        ui.toggle(content,"Сортировать по непрочитанным","Непрочитанные чаты наверху списка",AppConfig.sortByUnread){if(it!=AppConfig.sortByUnread)AppConfig.toggleSortByUnread()}
        ui.toggle(content,"Разархивировать свайпом","Свайп по архиву возвращает чат в список",AppConfig.unarchiveOnSwipe){if(it!=AppConfig.unarchiveOnSwipe)AppConfig.toggleUnarchiveOnSwipe()}
        ui.toggle(content,"Скрыть время в видео","Не показывать длительность на видео",AppConfig.hideVideoTimestamp){if(it!=AppConfig.hideVideoTimestamp)AppConfig.toggleHideVideoTimestamp()}
        ui.toggle(content,"Показывать секунды","Время сообщений с секундами",AppConfig.showSeconds){if(it!=AppConfig.showSeconds)AppConfig.toggleShowSeconds()}
        ui.toggle(content,"Скрыть хвостик пузыря","Пузыри без треугольного хвостика",AppConfig.hideBubbleTail){if(it!=AppConfig.hideBubbleTail)AppConfig.toggleHideBubbleTail()}
        ui.toggle(content,"Без скруглений","Прямые углы вместо скруглений",AppConfig.noRounding){if(it!=AppConfig.noRounding)AppConfig.toggleNoRounding()}
        ui.toggle(content,"Скрыть строку поиска","Убрать поиск с главного экрана",AppConfig.hideSearchBar){if(it!=AppConfig.hideSearchBar)AppConfig.toggleHideSearchBar()}
        ui.toggle(content,"Без разделителей","Убрать линии между элементами списков",AppConfig.disableDividers){if(it!=AppConfig.disableDividers)AppConfig.toggleDisableDividers()}
        ui.toggle(content,"Без анимации реакций","Реакции появляются без анимации",AppConfig.disableReactionAnim){if(it!=AppConfig.disableReactionAnim)AppConfig.toggleDisableReactionAnim()}
        ui.toggle(content,"Снег в чате","Эффект снега поверх чата (не тема)",AppConfig.drawSnowInChat){if(it!=AppConfig.drawSnowInChat)AppConfig.toggleDrawSnowInChat()}

        ui.button(content,"Скачать WeexMD3 плагин",R.drawable.weexgram_download){context.startActivity(Intent(context,WeexWelcomeActivity::class.java))}
        content.addView(ui.label("Внешний плагин не нужен для встроенного плеера. При его выборе встроенная версия отключается. После смены дизайна переоткройте этот экран/плеер.",14f,true))
        fragmentView=scroll;return scroll
    }
}
