// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import kotlin.math.roundToInt

/** Native replacement for the visual building blocks of plugin 3.21.0 SettingsUI. */
class SettingsUI(val context: Context) {
    fun dp(n: Int)=(n*context.resources.displayMetrics.density+.5f).toInt()
    private val systemNight = (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    // WeexConfig.palette: 0 системная, 1 светлая, 2 тёмная.
    private val night = when (WeexConfig.palette) { 1 -> false; 2 -> true; else -> systemNight }
    // Palette from WeexMD3-Keyboard 2.20.30 (values/colors.xml, values-night/colors.xml, values-v31 Monet).
    private fun pick(light: Int, dark: Int) = if (night) dark else light
    private fun dyn(id: Int, fallback: Int) = if (android.os.Build.VERSION.SDK_INT >= 31 && WeexConfig.monet) context.getColor(id) else fallback
    // AMOLED is applied only in the dark palette. It does not touch the light palette.
    val surface=if (night && WeexConfig.amoled) 0xff000000.toInt() else pick(0xfff8f9fc.toInt(), 0xff111111.toInt())
    val high=pick(0xffeaedf5.toInt(), 0xff2b2b2d.toInt())
    // Пресеты акцента (светлый акцент; в тёмной палитре берём светлый оттенок того же тона).
    private val accentPresets = listOf(0xff0b57d0, 0xff006a6a, 0xff386a20, 0xff6750a4, 0xff984061, 0xff8b5000,
        0xffba1a1a, 0xff3f51b5, 0xff6d4c41, 0xff475569, 0xff00658d, 0xff5b6100).map { it.toInt() }
    private fun presetAccent(index: Int) = accentPresets[index.coerceIn(0, accentPresets.size - 1)]
    private val useMonet = android.os.Build.VERSION.SDK_INT >= 31 && WeexConfig.monet
    val primary = if (useMonet) dyn(if (night) android.R.color.system_accent1_200 else android.R.color.system_accent1_600, 0)
        else if (WeexConfig.accent > 0) (if (night) ColorUtils.blendARGB(presetAccent(WeexConfig.accent - 1), 0xffffffff.toInt(), 0.35f) else presetAccent(WeexConfig.accent - 1))
        else pick(0xff0b57d0.toInt(), 0xffa8c7fa.toInt())
    val primaryContainer = if (useMonet) dyn(if (night) android.R.color.system_accent1_700 else android.R.color.system_accent1_100, 0)
        else if (WeexConfig.accent > 0) ColorUtils.blendARGB(primary, surface, if (night) 0.6f else 0.8f)
        else pick(0xffd3e3fd.toInt(), 0xff0842a0.toInt())
    val text=pick(0xff1c1d21.toInt(), 0xffe6e6ea.toInt())
    // Контраст 0..1 приближает второстепенный текст к основному.
    val muted=ColorUtils.blendARGB(pick(0xff444750.toInt(), 0xffc1c3cc.toInt()), this.text, WeexConfig.contrast.coerceIn(0f,1f) * 0.5f)
    fun rounded(color: Int,radius: Int=28)=GradientDrawable().apply {setColor(color);cornerRadius=dp(radius).toFloat()}
    fun column()=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL}
    fun label(value: String,size: Float=16f,secondary: Boolean=false)=TextView(context).apply {
        text=value;textSize=size;setTextColor(if(secondary)muted else this@SettingsUI.text)
        typeface=Typeface.create(if(secondary)"sans-serif" else "sans-serif-medium",Typeface.NORMAL)
        setPadding(0,dp(4),0,dp(4))
    }
    fun card(parent: LinearLayout)=column().apply {
        setPadding(dp(20),dp(16),dp(20),dp(16));background=rounded(high,if(WeexConfig.design)28 else 8)
        parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(10)})
    }
    fun toggle(parent: LinearLayout,title: String,subtitle: String,value: Boolean,changed:(Boolean)->Unit) {
        val box=card(parent).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(88)}
        val texts=column().apply{setPadding(0,0,dp(12),0);addView(label(title));addView(label(subtitle,14f,true))}
        box.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
        val switch=MaterialSwitch(context).apply{isChecked=value;contentDescription=title;minimumHeight=dp(48);setOnCheckedChangeListener{_,v->changed(v)}}
        box.addView(switch);box.setOnClickListener{switch.isChecked=!switch.isChecked}
    }
    /** Бегунок: от min до max с шагом step. changed получает значение, если его двигает пользователь. */
    fun slider(parent: LinearLayout,title: String,min: Float,max: Float,step: Float,value: Float,format: (Float)->String,changed:(Float)->Unit) {
        val box=card(parent)
        val head=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        head.addView(label(title),LinearLayout.LayoutParams(0,-2,1f))
        val valueLabel=label(format(value),14f,true)
        head.addView(valueLabel)
        box.addView(head)
        val steps=((max-min)/step).roundToInt()
        val bar=SeekBar(context).apply{
            this.max=steps
            progress=((value-min)/step).roundToInt().coerceIn(0,steps)
            progressTintList=ColorStateList.valueOf(primary)
            thumbTintList=ColorStateList.valueOf(primary)
            contentDescription=title
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, p: Int, fromUser: Boolean) {
                    val v=min+p*step
                    valueLabel.text=format(v)
                    if(fromUser) changed(v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        box.addView(bar,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(4)})
    }
    /** Выбор одного варианта из нескольких: ряд кнопок, выбранная залита цветом акцента-контейнера. */
    fun choice(parent: LinearLayout,title: String,options: List<String>,selected: Int,changed:(Int)->Unit) {
        val box=card(parent)
        box.addView(label(title))
        val row=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL}
        box.addView(row,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)})
        fun render(sel: Int) {
            row.removeAllViews()
            options.forEachIndexed { i, option ->
                val on = i == sel
                val btn = MaterialButton(context).apply {
                    text=option;isAllCaps=false;minimumHeight=dp(44);minimumWidth=0;insetTop=0;insetBottom=0
                    backgroundTintList=ColorStateList.valueOf(if(on) primaryContainer else high)
                    setTextColor(if(on) this@SettingsUI.text else muted)
                    contentDescription="$title: $option"
                    setOnClickListener{ changed(i); render(i) }
                }
                row.addView(btn,LinearLayout.LayoutParams(0,-2,1f).apply{marginEnd=if(i<options.size-1)dp(6) else 0})
            }
        }
        render(selected)
    }
    /** Ряд цветных кружков для выбора акцента. index 0 = палитра клавиатуры, 1..N = пресеты. */
    fun swatches(parent: LinearLayout,title: String,count: Int,selected: Int,changed:(Int)->Unit) {
        val box=card(parent)
        box.addView(label(title))
        val row=LinearLayout(context).apply{orientation=LinearLayout.HORIZONTAL}
        val scroll=android.widget.HorizontalScrollView(context).apply{isHorizontalScrollBarEnabled=false;addView(row)}
        box.addView(scroll,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)})
        fun render(sel: Int) {
            row.removeAllViews()
            for (i in 0 until count) {
                val color = if (i == 0) 0xff0b57d0.toInt() else presetAccent(i - 1)
                val dot = View(context).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(color)
                        if (i == sel) setStroke(dp(3), this@SettingsUI.text)
                    }
                    contentDescription = "$title ${i + 1}"
                    setOnClickListener { changed(i); render(i) }
                }
                row.addView(dot, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) })
            }
        }
        render(selected)
    }
    fun button(parent: LinearLayout,title: String,icon: Int?=null,click:()->Unit): MaterialButton {
        return MaterialButton(context).apply {
            text=title;isAllCaps=false;minimumHeight=dp(52)
            if(icon!=null)setIconResource(icon)
            setOnClickListener{click()}
            parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(10)})
        }
    }
}
