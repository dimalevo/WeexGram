// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch

/** Native replacement for the visual building blocks of plugin 3.21.0 SettingsUI. */
class SettingsUI(val context: Context) {
    fun dp(n: Int)=(n*context.resources.displayMetrics.density+.5f).toInt()
    // Palette from WeexMD3-Keyboard 2.20.30 (values/colors.xml, values-night/colors.xml, values-v31 Monet).
    private val night = (context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES
    private fun pick(light: Int, dark: Int) = if (night) dark else light
    private fun dyn(id: Int, fallback: Int) = if (android.os.Build.VERSION.SDK_INT >= 31) context.getColor(id) else fallback
    val surface=pick(0xfff8f9fc.toInt(), 0xff111111.toInt())
    val high=pick(0xffeaedf5.toInt(), 0xff2b2b2d.toInt())
    val primary=dyn(if (night) android.R.color.system_accent1_200 else android.R.color.system_accent1_600, pick(0xff0b57d0.toInt(), 0xffa8c7fa.toInt()))
    val primaryContainer=dyn(if (night) android.R.color.system_accent1_700 else android.R.color.system_accent1_100, pick(0xffd3e3fd.toInt(), 0xff0842a0.toInt()))
    val text=pick(0xff1c1d21.toInt(), 0xffe6e6ea.toInt())
    val muted=pick(0xff444750.toInt(), 0xffc1c3cc.toInt())
    fun rounded(color: Int,radius: Int=28)=GradientDrawable().apply {setColor(color);cornerRadius=dp(radius).toFloat()}
    fun column()=LinearLayout(context).apply{orientation=LinearLayout.VERTICAL}
    fun label(value: String,size: Float=16f,secondary: Boolean=false)=TextView(context).apply {
        text=value;textSize=size;setTextColor(if(secondary)muted else this@SettingsUI.text)
        typeface=Typeface.create(if(secondary)"sans-serif" else "sans-serif-medium",Typeface.NORMAL)
        setPadding(0,dp(4),0,dp(4))
    }
    fun card(parent: LinearLayout)=column().apply {
        setPadding(dp(20),dp(16),dp(20),dp(16));background=rounded(high,if(WeexConfig.design)28 else 8)
        parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(10)})
    }
    fun toggle(parent: LinearLayout,title: String,subtitle: String,value: Boolean,changed:(Boolean)->Unit) {
        val box=card(parent).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;minimumHeight=dp(88)}
        val texts=column().apply{setPadding(0,0,dp(12),0);addView(label(title));addView(label(subtitle,14f,true))}
        box.addView(texts,LinearLayout.LayoutParams(0,-2,1f))
        val switch=MaterialSwitch(context).apply{isChecked=value;contentDescription=title;minimumHeight=dp(48);setOnCheckedChangeListener{_,v->changed(v)}}
        box.addView(switch);box.setOnClickListener{switch.isChecked=!switch.isChecked}
    }
    fun button(parent: LinearLayout,title: String,icon: Int?=null,click:()->Unit): MaterialButton {
        return MaterialButton(context).apply {
            text=title;isAllCaps=false;minimumHeight=dp(52)
            if(icon!=null)setIconResource(icon)
            setOnClickListener{click()}
            parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(10)})
        }
    }
}
