// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicInteger

data class LyricLine(val timeMs: Long,val text: String)
data class Lyrics(val lines: List<LyricLine>,val plain: String,val instrumental: Boolean=false)

object LrcParser {
    private val timestamp=Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")
    fun parse(text: String):List<LyricLine>{
        val offset=Regex("\\[offset:([+-]?\\d+)]",RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 0
        val result=ArrayList<LyricLine>()
        text.lineSequence().forEach { raw ->
            val stamps=timestamp.findAll(raw).toList();val value=raw.replace(timestamp,"").trim()
            stamps.forEach { m ->
                val seconds=m.groupValues[2].toInt()
                if(seconds<60){val fraction=m.groupValues[3].padEnd(3,'0').take(3).toLong();result.add(LyricLine(((m.groupValues[1].toLong()*60+seconds)*1000+fraction+offset).coerceAtLeast(0),value))}
            }
        }
        return result.sortedBy{it.timeMs}.distinct()
    }
}

/** Track metadata only; HTTPS, explicit user opt-in, bounded responses, no Telegram tokens. */
class LyricsRepository {
    private val executor=Executors.newSingleThreadExecutor()
    private val main=Handler(Looper.getMainLooper())
    private val generation=AtomicInteger()
    private var task: Future<*>?=null
    private val cache=object:LinkedHashMap<String,Lyrics>(24,.75f,true){override fun removeEldestEntry(e:MutableMap.MutableEntry<String,Lyrics>?)=size>20}
    fun cancel(){generation.incrementAndGet();task?.cancel(true)}
    fun close(){cancel();executor.shutdownNow()}
    fun load(artist: String,title: String,duration: Int,callback:(Result<Lyrics>)->Unit){
        cancel();val ticket=generation.get();val key="$artist\u0000$title\u0000$duration"
        val cached=synchronized(cache){cache[key]};if(cached!=null){callback(Result.success(cached));return}
        task=executor.submit {
            val result=runCatching {
                val query="artist_name=${enc(artist)}&track_name=${enc(title)}"+if(duration in 1..3600)"&duration=$duration" else ""
                val exact=request("get?$query")
                val json=if(exact!=null)JSONObject(exact)else{
                    val array=JSONArray(request("search?artist_name=${enc(artist)}&track_name=${enc(title)}") ?: "[]")
                    (0 until array.length()).map{array.getJSONObject(it)}.filter{
                        normalize(it.optString("artistName"))==normalize(artist) && normalize(it.optString("trackName"))==normalize(title) && kotlin.math.abs(it.optDouble("duration")-duration)<=3
                    }.minByOrNull{kotlin.math.abs(it.optDouble("duration")-duration)} ?: error("Точного совпадения в LRCLIB нет")
                }
                val synced=json.optString("syncedLyrics").takeUnless{it=="null"}.orEmpty()
                val plain=json.optString("plainLyrics").takeUnless{it=="null"}.orEmpty()
                Lyrics(LrcParser.parse(synced),plain,json.optBoolean("instrumental")).also {synchronized(cache){cache[key]=it}}
            }
            main.post {if(generation.get()==ticket)callback(result)}
        }
    }
    private fun normalize(s:String)=s.trim().lowercase(Locale.ROOT).replace(Regex("\\s+")," ")
    private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
    private fun request(path:String):String?{
        RateGate.before()
        val connection=URL("https://lrclib.net/api/$path").openConnection() as HttpURLConnection
        try {
            connection.connectTimeout=8000;connection.readTimeout=10000;connection.instanceFollowRedirects=false
            connection.setRequestProperty("User-Agent","WeexGram/0.1 (NimarkoGram fork; https://github.com/Ettacent/NimarkoGram)")
            connection.setRequestProperty("Accept","application/json")
            val code=connection.responseCode
            if(code==429 || code==503){RateGate.cooldown(connection.getHeaderField("Retry-After"));error("LRCLIB временно ограничил запросы. Повторите позже.")}
            if(code==404)return null
            check(code==200){"LRCLIB: HTTP ${connection.responseCode}"}
            check(connection.contentType?.contains("json",true)==true){"LRCLIB вернул не JSON"}
            return connection.inputStream.use { input ->
                val out=ByteArrayOutputStream();val buffer=ByteArray(8192)
                while(true){if(Thread.currentThread().isInterrupted)error("Запрос отменён");val count=input.read(buffer);if(count<0)break;check(out.size()+count<=512*1024){"Слишком большой ответ LRCLIB"};out.write(buffer,0,count)}
                out.toString("UTF-8")
            }
        }finally{connection.disconnect()}
    }
}

private object RateGate {
    private var next=0L
    private var blocked=0L
    fun before(){
        val wait=synchronized(this){
            val now=android.os.SystemClock.elapsedRealtime()
            check(now>=blocked){"LRCLIB: действует пауза Retry-After"}
            val start=maxOf(next,now);next=start+300;start-now
        }
        if(wait>0)Thread.sleep(wait)
    }
    @Synchronized fun cooldown(header:String?){
        val seconds=header?.toLongOrNull() ?: runCatching {
            val date=java.text.SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.US).parse(header.orEmpty())
            ((date?.time ?: System.currentTimeMillis())-System.currentTimeMillis()+999)/1000
        }.getOrDefault(60)
        blocked=android.os.SystemClock.elapsedRealtime()+seconds.coerceIn(1,31536000)*1000
    }
}
