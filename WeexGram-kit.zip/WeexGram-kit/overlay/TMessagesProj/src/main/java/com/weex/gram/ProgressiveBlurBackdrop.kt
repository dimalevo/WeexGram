// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.os.Build
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.min

/** Snapshot-only, banded progressive blur on API 31+. Never blurs the foreground controls. */
class ProgressiveBlurBackdrop(context: Context) : FrameLayout(context) {
    private var snapshot: Bitmap?=null
    init {isClickable=false;importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS}
    fun capture(activity: Activity) {
        release()
        if(Build.VERSION.SDK_INT<31 || !WeexConfig.blur)return
        // Do not snapshot a FLAG_SECURE window (passcode / sensitive UI).
        if(activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE != 0)return
        val source=activity.window.decorView
        if(source.width<=0 || source.height<=0)return
        try {
            val factor=min(1f,512f/source.width)
            val bitmap=Bitmap.createBitmap((source.width*factor).toInt().coerceAtLeast(1),(source.height*factor).toInt().coerceAtLeast(1),Bitmap.Config.ARGB_8888)
            val canvas=Canvas(bitmap);canvas.scale(factor,factor);source.draw(canvas);snapshot=bitmap
            for(i in 0..3){
                val band=Band(context,i)
                val image=ImageView(context).apply {
                    scaleType=ImageView.ScaleType.CENTER_CROP;setImageBitmap(bitmap)
                    setRenderEffect(RenderEffect.createBlurEffect(4f+i*8f,4f+i*8f,Shader.TileMode.CLAMP))
                }
                band.addView(image,LayoutParams(-1,-1));addView(band,LayoutParams(-1,-1))
            }
        }catch(_:RuntimeException){release()}catch(_:OutOfMemoryError){release()}
    }
    fun release(){removeAllViews();snapshot=null} // Do not recycle bitmaps still referenced by RenderThread.
    override fun onDetachedFromWindow(){release();super.onDetachedFromWindow()}
    private class Band(context: Context,val index: Int):FrameLayout(context){
        private val mask=Paint(Paint.ANTI_ALIAS_FLAG).apply{xfermode=PorterDuffXfermode(PorterDuff.Mode.DST_IN)}
        override fun dispatchDraw(canvas: Canvas){
            if(width==0 || height==0)return
            val save=canvas.saveLayer(0f,0f,width.toFloat(),height.toFloat(),null)
            super.dispatchDraw(canvas)
            // Overlapping triangular masks blend radii across the vertical axis; no hard stripes.
            val colors=IntArray(5){point->Color.argb(if(point==index)255 else if(kotlin.math.abs(point-index)==1)100 else 0,255,255,255)}
            mask.shader=LinearGradient(0f,0f,0f,height.toFloat(),colors,null,Shader.TileMode.CLAMP)
            canvas.drawRect(0f,0f,width.toFloat(),height.toFloat(),mask);canvas.restoreToCount(save)
        }
    }
}
