// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.content.Context
import android.content.res.Configuration
import android.view.ContextThemeWrapper
import org.telegram.messenger.ApplicationLoader
import org.telegram.messenger.R
import org.telegram.ui.ActionBar.Theme

object WeexConfig {
    private val prefs get() = ApplicationLoader.applicationContext.getSharedPreferences("weexgram", Context.MODE_PRIVATE)
    var player: Boolean get()=prefs.getBoolean("player",true);set(v){prefs.edit().putBoolean("player",v).apply()}
    var design: Boolean get()=prefs.getBoolean("design",true);set(v){prefs.edit().putBoolean("design",v).apply()}
    var animations: Boolean get()=prefs.getBoolean("animations",true);set(v){prefs.edit().putBoolean("animations",v).apply()}
    var blur: Boolean get()=prefs.getBoolean("blur",false);set(v){prefs.edit().putBoolean("blur",v).apply()}
    var lyrics: Boolean get()=prefs.getBoolean("lyrics",false);set(v){prefs.edit().putBoolean("lyrics",v).apply()}
    var welcomed: Boolean get()=prefs.getBoolean("welcomed",false);set(v){prefs.edit().putBoolean("welcomed",v).apply()}
    fun themed(context: Context): Context {
        val config=Configuration(context.resources.configuration)
        config.uiMode=(config.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
            if(Theme.isCurrentThemeDark()) Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO
        return ContextThemeWrapper(context.createConfigurationContext(config),R.style.Theme_WeexGram)
    }
}
