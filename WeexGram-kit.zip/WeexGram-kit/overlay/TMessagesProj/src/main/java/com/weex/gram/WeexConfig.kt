// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.content.Context
import android.content.res.Configuration
import android.view.ContextThemeWrapper
import org.telegram.messenger.ApplicationLoader
import org.telegram.messenger.R
import org.telegram.ui.ActionBar.Theme

object WeexConfig {
    private val prefs get() = ApplicationLoader.applicationContext.getSharedPreferences("weexgram", Context.MODE_PRIVATE)
    var player: Boolean get()=prefs.getBoolean("player",true);set(v){prefs.edit().putBoolean("player",v).apply()}
    var design: Boolean get()=prefs.getBoolean("design",true);set(v){prefs.edit().putBoolean("design",v).apply()}
    var animations: Boolean get()=prefs.getBoolean("animations",true);set(v){prefs.edit().putBoolean("animations",v).apply()}
    var blur: Boolean get()=prefs.getBoolean("blur",false);set(v){prefs.edit().putBoolean("blur",v).apply()}
    var lyrics: Boolean get()=prefs.getBoolean("lyrics",false);set(v){prefs.edit().putBoolean("lyrics",v).apply()}
    // MD3 settings, порция 1 (палитра, Monet, AMOLED, схема движения, скорость, пружина, уменьшить движение, появление).
    var palette: Int get()=prefs.getInt("palette",0);set(v){prefs.edit().putInt("palette",v).apply()}   // 0 системная, 1 светлая, 2 тёмная
    var monet: Boolean get()=prefs.getBoolean("monet",true);set(v){prefs.edit().putBoolean("monet",v).apply()}
    var amoled: Boolean get()=prefs.getBoolean("amoled",false);set(v){prefs.edit().putBoolean("amoled",v).apply()}
    var motionScheme: Int get()=prefs.getInt("motionScheme",1);set(v){prefs.edit().putInt("motionScheme",v).apply()}  // 0 стандартная, 1 выразительная
    var motionSpeed: Float get()=prefs.getFloat("motionSpeed",1f);set(v){prefs.edit().putFloat("motionSpeed",v).apply()}  // 0.5..2.0
    var pressSpring: Boolean get()=prefs.getBoolean("pressSpring",true);set(v){prefs.edit().putBoolean("pressSpring",v).apply()}
    var reduceMotion: Boolean get()=prefs.getBoolean("reduceMotion",false);set(v){prefs.edit().putBoolean("reduceMotion",v).apply()}
    var enterAnimation: Boolean get()=prefs.getBoolean("enterAnimation",true);set(v){prefs.edit().putBoolean("enterAnimation",v).apply()}
    // Порция 2: цвет акцента (0 = палитра клавиатуры, 1..11 = пресеты) и контраст текста 0..1.
    var accent: Int get()=prefs.getInt("accent",0);set(v){prefs.edit().putInt("accent",v).apply()}
    var contrast: Float get()=prefs.getFloat("contrast",0f);set(v){prefs.edit().putFloat("contrast",v).apply()}
    var welcomed: Boolean get()=prefs.getBoolean("welcomed",false);set(v){prefs.edit().putBoolean("welcomed",v).apply()}
    fun themed(context: Context): Context {
        val config=Configuration(context.resources.configuration)
        config.uiMode=(config.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv()) or
            if(Theme.isCurrentThemeDark()) Configuration.UI_MODE_NIGHT_YES else Configuration.UI_MODE_NIGHT_NO
        return ContextThemeWrapper(context.createConfigurationContext(config),R.style.Theme_WeexGram)
    }
}
