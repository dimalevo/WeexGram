// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.app.Activity
import android.content.Context
import android.content.Intent
import java.util.concurrent.atomic.AtomicBoolean
import org.telegram.ui.ActionBar.BottomSheet
import org.telegram.ui.ActionBar.Theme
import org.telegram.ui.Components.AudioPlayerAlert

object WeexEntry {
    private val welcomeStarted=AtomicBoolean(false)
    @JvmStatic fun create(context:Context,provider:Theme.ResourcesProvider?):BottomSheet {
        val external=try{app.nimarkogram.messenger.plugins.PluginsController.getInstance().plugins["weex_md3"]?.isEnabled==true}catch(_:Exception){false}
        return if(WeexConfig.player && !external)Sheet(context,provider)else AudioPlayerAlert(context,provider)
    }
    @JvmStatic fun maybeWelcome(activity:Activity){
        if(WeexConfig.welcomed || !welcomeStarted.compareAndSet(false,true))return
        activity.window.decorView.postDelayed({
            if(activity.isFinishing || activity.isDestroyed){welcomeStarted.set(false);return@postDelayed}
            try{activity.startActivity(Intent(activity,WeexWelcomeActivity::class.java))}
            catch(_:RuntimeException){welcomeStarted.set(false)}
        },650)
    }
}
