// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.animation.ValueAnimator
import android.view.View
import android.view.animation.PathInterpolator
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

object WeexMotion {
    // Plugin-style timing for finite transitions. A PathInterpolator is NOT a physical spring.
    val emphasized=PathInterpolator(.2f,0f,0f,1f)
    fun enabled()=WeexConfig.animations && (android.os.Build.VERSION.SDK_INT<26 || ValueAnimator.areAnimatorsEnabled())
    fun enter(view: View) {
        view.animate().cancel()
        if(!enabled()){view.alpha=1f;view.translationY=0f;return}
        view.alpha=0f;view.translationY=24*view.resources.displayMetrics.density
        view.animate().alpha(1f).translationY(0f).setDuration(360).setInterpolator(emphasized).start()
    }
    fun press(view: View,down: Boolean) {
        val target=if(down).96f else 1f
        if(!enabled()){view.scaleX=target;view.scaleY=target;return}
        listOf(SpringAnimation.SCALE_X,SpringAnimation.SCALE_Y).forEach { property ->
            val tag=if(property==SpringAnimation.SCALE_X)org.telegram.messenger.R.id.weexgram_spring_x else org.telegram.messenger.R.id.weexgram_spring_y
            val spring=(view.getTag(tag) as? SpringAnimation) ?: SpringAnimation(view,property).also {
                it.spring=SpringForce().setStiffness(800f).setDampingRatio(.6f);view.setTag(tag,it)
            }
            spring.animateToFinalPosition(target)
        }
    }
    fun stop(view: View){view.animate().cancel();listOf(org.telegram.messenger.R.id.weexgram_spring_x,org.telegram.messenger.R.id.weexgram_spring_y).forEach{(view.getTag(it) as? SpringAnimation)?.cancel()}}
}
