// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.animation.ValueAnimator
import android.view.View
import android.view.animation.PathInterpolator
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

object WeexMotion {
    // Plugin-style timing for finite transitions. A PathInterpolator is NOT a physical spring.
    val emphasized = PathInterpolator(.2f, 0f, 0f, 1f)

    // Values from androidx/compose/material3 tokens (v0_14_0 expressive, v0_14_0 standard).
    // Expressive fast spatial: stiffness 800, damping 0.6. Standard default spatial: stiffness 700, damping 0.9.
    private fun stiffness(): Float {
        val base = if (WeexConfig.motionScheme == 0) 700f else 800f
        val speed = WeexConfig.motionSpeed.coerceIn(0.5f, 2f)
        return base * speed * speed
    }
    private fun damping(): Float = if (WeexConfig.motionScheme == 0) 0.9f else 0.6f

    // Reduce motion overrides everything, including the system-independent WeexGram toggle.
    fun enabled() = WeexConfig.animations && !WeexConfig.reduceMotion &&
        (android.os.Build.VERSION.SDK_INT < 26 || ValueAnimator.areAnimatorsEnabled())

    private fun duration(base: Long): Long = (base / WeexConfig.motionSpeed.coerceIn(0.5f, 2f)).toLong()

    fun enter(view: View) {
        view.animate().cancel()
        if (!enabled() || !WeexConfig.enterAnimation) { view.alpha = 1f; view.translationY = 0f; return }
        view.alpha = 0f
        view.translationY = 24 * view.resources.displayMetrics.density
        view.animate().alpha(1f).translationY(0f).setDuration(duration(360)).setInterpolator(emphasized).start()
    }

    fun press(view: View, down: Boolean) {
        val target = if (down) .96f else 1f
        if (!enabled() || !WeexConfig.pressSpring) { view.scaleX = target; view.scaleY = target; return }
        listOf(SpringAnimation.SCALE_X, SpringAnimation.SCALE_Y).forEach { property ->
            val tag = if (property == SpringAnimation.SCALE_X) org.telegram.messenger.R.id.weexgram_spring_x else org.telegram.messenger.R.id.weexgram_spring_y
            val spring = (view.getTag(tag) as? SpringAnimation) ?: SpringAnimation(view, property).also { view.setTag(tag, it) }
            // Re-apply every press so a scheme or speed change takes effect without restarting the app.
            spring.spring = SpringForce().setStiffness(stiffness()).setDampingRatio(damping())
            spring.animateToFinalPosition(target)
        }
    }

    fun stop(view: View) {
        view.animate().cancel()
        listOf(org.telegram.messenger.R.id.weexgram_spring_x, org.telegram.messenger.R.id.weexgram_spring_y)
            .forEach { (view.getTag(it) as? SpringAnimation)?.cancel() }
    }
}
