// SPDX-License-Identifier: GPL-2.0-or-later
// WeexGram native integration, 2026. Upstream credits are retained in NOTICE.md.
package com.weex.gram

import android.content.Context
import android.graphics.Canvas
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

/** LRCLIB provides line timing. The within-line fill is an estimate, not word-level timestamps. */
class KaraokeView(context: Context,private val ui: SettingsUI):View(context){
    private var lines=emptyList<LyricLine>()
    private var layouts=emptyList<StaticLayout>()
    private var tops=emptyList<Int>()
    private var duration=0L
    private var position=0L
    private var active=-1
    var onActiveLine:((Int)->Unit)?=null
    fun setLyrics(value:List<LyricLine>,durationMs:Long){lines=value;duration=durationMs;active=-1;layouts=emptyList();requestLayout();invalidate()}
    fun position(ms:Long){
        position=ms
        var low=0;var high=lines.size-1;var next=-1
        while(low<=high){val mid=(low+high)/2;if(lines[mid].timeMs<=ms){next=mid;low=mid+1}else high=mid-1}
        if(next!=active){active=next;tops.getOrNull(active)?.let{onActiveLine?.invoke(it)}}
        invalidate()
    }
    override fun onMeasure(w:Int,h:Int){
        val width=MeasureSpec.getSize(w);val usable=(width-ui.dp(16)).coerceAtLeast(1)
        val out=ArrayList<StaticLayout>();val positions=ArrayList<Int>();var top=ui.dp(16)
        lines.forEach { line ->
            val paint=TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{textSize=20*resources.displayMetrics.scaledDensity;typeface=Typeface.create("sans-serif-medium",0)}
            val layout=StaticLayout.Builder.obtain(line.text,0,line.text.length,paint,usable).setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build()
            positions.add(top);out.add(layout);top+=layout.height+ui.dp(24)
        }
        layouts=out;tops=positions;setMeasuredDimension(width,resolveSize(top+ui.dp(16),h))
    }
    override fun onDraw(canvas:Canvas){
        super.onDraw(canvas)
        layouts.forEachIndexed { i,layout ->
            val save=canvas.save();canvas.translate(ui.dp(8).toFloat(),tops[i].toFloat());layout.paint.color=ui.muted;layout.draw(canvas)
            if(i==active){
                val end=lines.getOrNull(i+1)?.timeMs ?: duration.coerceAtLeast(lines[i].timeMs+4000)
                val progress=((position-lines[i].timeMs).toFloat()/(end-lines[i].timeMs).coerceAtLeast(1)).coerceIn(0f,1f)
                canvas.clipRect(0f,0f,layout.width*progress,layout.height.toFloat());layout.paint.color=ui.primary;layout.draw(canvas)
            }
            canvas.restoreToCount(save)
        }
    }
}
