#!/usr/bin/env bash
# Build on your own workstation; do not publish private.properties or signing keys.
set -euo pipefail
ROOT="${1:?Usage: build-local.sh /path/to/NimarkoGram [--all-abis]}"
ROOT="$(cd "$ROOT" && pwd)"
cd "$ROOT"
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
: "${JAVA_HOME:?Set JAVA_HOME to JDK 17}"
[ -n "$SDK" ] || { echo 'Set ANDROID_HOME to Android SDK.' >&2; exit 1; }
export PATH="$JAVA_HOME/bin:$PATH"
java -version 2>&1 | grep -q 'version "17\.' || { echo 'JDK 17 required.' >&2; exit 1; }
PY="${NIMARKO_BUILD_PYTHON:-python3.11}"
"$PY" -c 'import sys; assert sys.version_info[:2] == (3,11), "Python 3.11 required"'
export NIMARKO_BUILD_PYTHON="$PY"
for path in platforms/android-36/android.jar build-tools/36.0.0/aapt2 ndk/26.3.11579264/source.properties cmake/3.22.1/bin/cmake; do
  [ -f "$SDK/$path" ] || { echo "Missing SDK component: $path" >&2; exit 1; }
done
submodules="$(git submodule status --recursive)"
if printf '%s\n' "$submodules" | grep -q '^-'; then
  echo 'Initialize submodules: git submodule update --init --recursive' >&2; exit 1
fi
python3 - <<'PY'
import os,pathlib,re
p=pathlib.Path('private.properties')
values={}
if p.exists():
    for line in p.read_text().splitlines():
        if '=' in line and not line.lstrip().startswith('#'):
            k,v=line.split('=',1);values[k.strip()]=v.strip()
api=os.getenv('TELEGRAM_API_ID',values.get('TELEGRAM_API_ID',''))
hash_=os.getenv('TELEGRAM_API_HASH',values.get('TELEGRAM_API_HASH',''))
assert api.isdigit() and int(api)>0, 'Set your own TELEGRAM_API_ID'
assert re.fullmatch('[a-fA-F0-9]{32}',hash_), 'Set your own TELEGRAM_API_HASH'
print('Telegram configuration is present; values are not printed.')
PY
export NIMARKO_FIREBASE_ENABLED="${NIMARKO_FIREBASE_ENABLED:-false}"
export NIMARKO_CRASHLYTICS_UPLOAD=false
# WeexGram icon: replace every launcher PNG of both modules with the WeexGram icon and drop adaptive XML so the PNGs are used.
for mod in TMessagesProj TMessagesProj_AppStandalone; do
  res="$ROOT/$mod/src/main/res"
  [ -d "$res" ] || continue
  for d in "$res"/mipmap-*; do
    dens="${d##*mipmap-}"
    src="$ROOT/weexgram/icons/$dens.png"
    [ -f "$src" ] || continue
    for f in "$d"/*launcher*.png; do [ -f "$f" ] && cp "$src" "$f"; done
  done
  # Adaptive icon: keep the XML, point it at WeexGram layers (keyboard glyph on primary container).
  for x in "$res"/mipmap-anydpi-v26/*launcher*.xml; do
    [ -f "$x" ] || continue
    printf '%s\n' '<?xml version="1.0" encoding="utf-8"?>' '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">' \
      '    <background android:drawable="@drawable/weexgram_ic_bg"/>' \
      '    <foreground android:drawable="@mipmap/weexgram_ic_fg"/>' '</adaptive-icon>' > "$x"
  done
done
echo 'WeexGram icon applied.'
abi=(-PngArm64Only)
[ "${2:-}" != '--all-abis' ] || abi=()
chmod +x gradlew
./gradlew :TMessagesProj_AppStandalone:assembleAfatStandalone "${abi[@]}" \
  --no-daemon --max-workers="${WEEX_WORKERS:-2}" \
  -Dorg.gradle.jvmargs="${WEEX_GRADLE_JVMARGS:--Xmx6g -XX:MaxMetaspaceSize=1g -Dfile.encoding=UTF-8}" \
  -Pkotlin.compiler.execution.strategy=in-process
APK='TMessagesProj_AppStandalone/build/outputs/apk/afat/standalone/app.apk'
[ -s "$APK" ] || { echo "Expected APK not found: $APK" >&2; exit 1; }
mkdir -p weexgram-out
cp "$APK" weexgram-out/WeexGram.apk
BT="$SDK/build-tools/36.0.0"
if [ -n "${RELEASE_STORE_FILE:-}" ]; then
  # Release key from repository secrets: the same key for every build, so updates install over old ones.
  "$BT/zipalign" -f -P 16 4 weexgram-out/WeexGram.apk weexgram-out/aligned.apk
  "$BT/apksigner" sign --ks "$RELEASE_STORE_FILE" --ks-key-alias "$RELEASE_KEY_ALIAS" \
    --ks-pass env:RELEASE_STORE_PASSWORD --key-pass env:RELEASE_KEY_PASSWORD \
    --out weexgram-out/WeexGram.apk weexgram-out/aligned.apk
  rm weexgram-out/aligned.apk
  echo 'Signed with the release key from repository secrets.'
elif ! "$BT/apksigner" verify weexgram-out/WeexGram.apk >/dev/null 2>&1; then
  # Local DEVELOPMENT key only. Persist it yourself if you need to install subsequent updates.
  mkdir -p .weexgram-private
  if [ ! -f .weexgram-private/development.jks ]; then
    keytool -genkeypair -keystore .weexgram-private/development.jks -storepass android -keypass android \
      -alias weexgram-dev -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=WeexGram Development'
  fi
  "$BT/zipalign" -f -P 16 4 weexgram-out/WeexGram.apk weexgram-out/aligned.apk
  "$BT/apksigner" sign --ks .weexgram-private/development.jks --ks-key-alias weexgram-dev \
    --ks-pass pass:android --key-pass pass:android --out weexgram-out/WeexGram.apk weexgram-out/aligned.apk
  rm weexgram-out/aligned.apk
  echo 'WARNING: signed with a local development key, not a production release key.'
fi
"$BT/apksigner" verify --verbose --print-certs weexgram-out/WeexGram.apk
"$BT/aapt2" dump badging weexgram-out/WeexGram.apk > weexgram-out/badging.txt
head -n 5 weexgram-out/badging.txt
sha256sum weexgram-out/WeexGram.apk > weexgram-out/SHA256.txt
printf '\nAPK: %s/weexgram-out/WeexGram.apk\n' "$ROOT"
