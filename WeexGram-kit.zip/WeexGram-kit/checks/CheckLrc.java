import com.weex.gram.*;
import java.util.*;
public class CheckLrc {
 public static void main(String[] args){
  List<LyricLine> a=LrcParser.INSTANCE.parse("[offset:-50]\n[00:01.20][00:02.345]Hello\n[00:60.00]Invalid\n[00:00.1]Start\n[00:01.20]Hello");
  if(a.size()!=3 || a.get(0).getTimeMs()!=50 || a.get(1).getTimeMs()!=1150 || a.get(2).getTimeMs()!=2295)throw new AssertionError(a.toString());
  if(!a.get(1).getText().equals("Hello"))throw new AssertionError("text");
  if(!LrcParser.INSTANCE.parse("plain text\n[ar:Artist]").isEmpty())throw new AssertionError("metadata");
  System.out.println("PASS: LRC fractions, signed offset, multiple timestamps, sorting, deduplication and invalid seconds.");
 }
}
