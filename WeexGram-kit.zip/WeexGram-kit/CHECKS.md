# Проверки — 2026-10-27

## Выполнено

1. База реально клонирована с GitHub; HEAD `0f1c6aa243d8509339f528f35887b6d91d051a03`. Основной checkout получен без рекурсивной инициализации всех native submodules.
2. Скачаны JDK 17, Android platform 36 и Build Tools 36.0.0 для ограниченной проверки новых модулей.
3. Все 10 новых Kotlin-файлов компилируются Kotlin 1.9.24 / JVM target 1.8 / Android API 36 с настоящими API Material 1.13.0, AppCompat, Core и DynamicAnimation. Для классов Telegram использованы минимальные Java-заглушки, соответствующие просмотренным публичным сигнатурам базы. В этом контрольном classpath часть вспомогательных AndroidX версий отличается от итогового resolution приложения. Поэтому это только проверка синтаксиса/типов новых файлов, НЕ успешная сборка NimarkoGram.
4. `aapt2` 36.0.0 успешно выполнил `compile --dir overlay/TMessagesProj/src/main/res`. Link полных ресурсов приложения не выполнялся.
5. JVM-проверка LRC: дробные секунды, отрицательный offset, несколько времён на одну строку, сортировка, дубли и невалидные секунды — PASS.
6. `git diff --check` — PASS. Patch применён к исходным версиям всех 21 изменённого tracked-файла, полученным через git show HEAD:path; результат побайтово совпадает с рабочими изменениями.
7. XML новых ресурсов и изменённого manifest разобраны XML-парсером. Наличие colorSurfaceContainerHigh подтверждено в реальном R.txt Material AAR.
8. SHA-256 bundled WeexMD3 совпадает с выбранным исходным WeexMD3_3_21_0.plugin.
9. `bash -n build-local.sh`, синтаксис Python apply.py проверены. Архив комплектуется SHA256.json для контроля содержимого.

10. apply.py реально выполнен на отдельном чистом sparse-checkout с тем же HEAD: проверены SHA-256, git apply и копирование overlay. git diff --check после установки — PASS. Это не запуск Gradle.

Основной большой checkout базы хранится в кэше; постоянный комплект — patch, overlay и точный commit для воспроизведения. Vendor/JNI исходники и Git pack размером сотни MB не дублируются в архиве.

## Не выполнено

- Полная Gradle-задача `:TMessagesProj_AppStandalone:assembleAfatStandalone`.
- Компиляция всех изменённых Java-файлов против полного проекта, AGP resource linking, CMake/NDK, Chaquopy и упаковка DEX/JNI.
- Подпись готового WeexGram APK: самого APK нет.
- Запуск GitHub Actions workflow с вашими секретами.
- Установка/вход в Telegram, аппаратное размытие, визуальные проверки, talkback и runtime lifecycle на телефоне.
- Полный аудит унаследованных сервисов NimarkoGram и полный функциональный паритет Python-плагина.

Для полной сборки нужны ваш API ID/hash (оставлены для локального ввода), Python 3.11, NDK 26.3.11579264/CMake 3.22.1, recursive submodules и существенно более ресурсоёмкая сборочная машина. В агентском окружении около 2 GB RAM. Проверки выше не являются доказательством, что весь форк уже собирается и работает.
