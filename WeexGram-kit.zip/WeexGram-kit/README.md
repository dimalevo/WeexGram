# WeexGram 0.1 — план, код и пошаговая сборка

**Статус: стартовая нативная интеграция, не готовый релиз. APK в этом комплекте отсутствует.**

Исходники NimarkoGram скачаны, точки встраивания найдены и изменены. Предоставлены Kotlin-модули, ресурсы, патч к точному коммиту, установщик патча, локальный сборочный скрипт и GitHub Actions workflow. Полная Gradle/NDK-сборка и запуск на устройстве не выполнялись. API-ключи по вашему выбору вносятся только локально.

Это НЕ полный построчный перенос всех ~10 тысяч строк WeexMD3 3.21.0. Переписано основное ядро: плеер, карточки настроек, управление воспроизведением, очередь, тексты, движения и выбор встроенной/внешней версии. Полный функциональный паритет и глобальная переделка Telegram не заявляются.

## 1. База и решения

- Репозиторий: https://github.com/Ettacent/NimarkoGram
- Зафиксированный коммит: `0f1c6aa243d8509339f528f35887b6d91d051a03`.
- Версия базы: 13.1.1. Её числовой versionName сохранён, чтобы не ломать проверки совместимости плагинов.
- База переноса: локальный `WeexMD3_3_21_0.plugin`, выбранный вами. Он же вложен в assets без изменения содержимого.
- Идентификатор standalone-приложения: **`com.weex.gram`**, отдельный от NimarkoGram. Java namespace Telegram остаётся `org.telegram.messenger`: его переименование сломало бы R/JNI и большую часть исходников.
- Material Components `1.13.0` и AndroidX DynamicAnimation уже используются базой. Новая тема `Theme.WeexGram` наследует `Theme.Material3.DayNight.NoActionBar` и применяется к новым поверхностям, а не принудительно ко всему Telegram.
- `minSdk 24` сохранён от NimarkoGram. Настройки клавиатуры WeexKeyboardMD3 к этому проекту не относятся.
- Идеи blur/движения реализованы самостоятельно; код Opexgram не скачивался и не копировался.

## 2. Архитектура: что куда встроено

### Изменения в существующих файлах

| Файл | Изменение |
|---|---|
| `org/telegram/ui/SettingsActivity.java` | Пункт WeexGram, ID 901; открывает `WeexSettingsFragment` |
| `org/telegram/ui/Components/FragmentContextView.java` | Две точки открытия музыкального плеера перенаправлены в фабрику |
| `org/telegram/ui/ChatActivity.java` | Открытие плеера через фабрику |
| `org/telegram/ui/ProfileActivity.java` | Открытие плеера через фабрику |
| `org/telegram/ui/LaunchActivity.java` | Фабрика плеера, запуск onboarding; отключён автоматический запрос upstream-обновлений |
| `TMessagesProj/src/main/AndroidManifest.xml` | Внутренняя, неэкспортируемая `WeexWelcomeActivity` |
| `TMessagesProj_AppStandalone/build.gradle` | Собственный applicationId |
| `gradle.properties`, локализованные `strings.xml` | Пакет и название WeexGram |
| `.gitignore` | Исключены локальные ключи и выходные APK |

### Новые классы: `com.weex.gram`

- **`WeexEntry.kt`** — единственная фабрика плеера. Выбирает встроенный `Sheet` или исходный `AudioPlayerAlert`. Если включён внешний плагин с ID `weex_md3`, встроенный плеер не используется.
- **`WeexConfig.kt`** — SharedPreferences: плеер, MD3-дизайн, анимации, blur, разрешение LRCLIB и завершение onboarding. Тематический Context следует светлой/тёмной теме Telegram.
- **`Sheet.kt`** — нативное ядро музыкальной шторки: обложка из `MediaController.audioInfo`, название/исполнитель, play/pause, предыдущий/следующий трек, seek, очередь первых 50 треков, режим текстов, переход к штатному плееру для остальных возможностей. Существующие MediaController, MusicPlayerService и MediaSession НЕ заменяются вторым движком. Мини-плеер сохраняется.
- **`SettingsUI.kt`** — Kotlin-переписывание базовых визуальных компонентов SettingsUI: карточки, заголовки, подписи, настоящие MaterialSwitch и MaterialButton.
- **`WeexSettingsFragment.kt`** — раздел WeexGram. Три основных переключателя плюс отдельные разрешения blur/LRCLIB. Изменения сохраняются сразу; открытый плеер/экран следует переоткрыть после изменения дизайна.
- **`WeexMotion.kt`** — конечные переходы через PathInterpolator и физические пружины кнопок через SpringAnimation. Это разные механизмы: PathInterpolator сам по себе НЕ является пружиной. Пружина: 800 / 0.6. Настройка анимаций и системное отключение учитываются.
- **`ProgressiveBlurBackdrop.kt`** — приближённый progressive blur из четырёх радиусов с перекрывающимися масками. Только фон новых Weex-поверхностей, Android 12/API 31+. На API 24–30 остаётся обычная подложка. Это статический снимок, не непрерывный живой blur. Снимки хранятся только в RAM; FLAG_SECURE запрещает захват. Ошибки/OOM дают fallback без размытия. По умолчанию выключено.
- **`LyricsRepository.kt`** — HTTPS `/api/get`, затем осторожный `/api/search`; точное совпадение исполнителя/названия и близкая длительность. Таймауты, предел ответа 512 KiB, последовательные запросы, ограничение частоты, Retry-After, отмена устаревших результатов, RAM-кэш 20 треков. Ключ API LRCLIB не вшивается.
- **`KaraokeView.kt`** — подсветка LRC-строк, следование за воспроизведением. Используется поле syncedLyrics: заполнение внутри строки приблизительное. Более новый формат LRCLIB `lyricsfile` с настоящими word-level timings пока не реализован.
- **`WeexWelcomeActivity.kt`** — первый запуск: встроенная версия либо «Скачать WeexMD3 плагин». Кнопка через системный SAF сохраняет вложенный `.plugin`; не устанавливает и не исполняет Python автоматически. После успешного сохранения встроенный плеер выключается.

Официальные Material Symbols Rounded скачаны из `google/material-design-icons` и включены в drawable вместе с лицензией. Заменены иконки новых Weex-экранов и их точки входа. **Все тысячи старых иконок Telegram глобально не заменялись.**

## 3. Сборка локально, без Android Studio

Рекомендуется Linux x86_64, SSD, порядка 16 GB RAM и достаточно места для SDK/NDK, native submodules и промежуточных файлов. Доступное агенту окружение с ~2 GB RAM, без полного NDK/native checkout не является подходящей средой для подтверждения такого APK. Для CI есть отдельный workflow.

### Шаг 1. Установить инструменты

Нужны `git`, `git-lfs` (если требуется вашим checkout), `unzip`, JDK 17, Python 3.11 и Android SDK command-line tools. Системный Python 3.13 не заменяет Python 3.11 для Chaquopy этой базы.

```bash
export JAVA_HOME=/absolute/path/to/jdk-17
export PATH="$JAVA_HOME/bin:$PATH"
export ANDROID_HOME=/absolute/path/to/android-sdk
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
export NIMARKO_BUILD_PYTHON=/absolute/path/to/python3.11

java -version
"$NIMARKO_BUILD_PYTHON" --version
sdkmanager --licenses
sdkmanager 'platforms;android-36' 'build-tools;36.0.0' \
  'ndk;26.3.11579264' 'cmake;3.22.1'
```

### Шаг 2. Получить точную базу со всеми submodules

```bash
git clone https://github.com/Ettacent/NimarkoGram.git WeexGram
cd WeexGram
git checkout 0f1c6aa243d8509339f528f35887b6d91d051a03
git submodule update --init --recursive
cd ..
```

Обычный clone без submodule update не содержит все исходники media3, JNI и jlatexmath. Не пытайтесь исправлять отсутствие этих файлов удалением include из settings.gradle: получите не тот клиент.

### Шаг 3. Применить комплект

Распакуйте архив рядом с исходниками, не внутрь их рабочего дерева:

```bash
unzip WeexGram-kit.zip
python3 WeexGram-kit/apply.py "$PWD/WeexGram"
```

Установщик проверяет коммит, чистоту дерева, SHA-256 комплекта, применимость patch и отсутствие конфликтов новых файлов. Затем применяет `nimarkogram.patch` и копирует `overlay`. Чужие изменения и private.properties не перезаписывает. Не запускайте второй раз поверх уже применённого комплекта.

### Шаг 4. Свои Telegram-ключи

```bash
cd WeexGram
cp private.properties.example private.properties
```

Откройте `private.properties` локальным редактором и заполните свои `TELEGRAM_API_ID` и `TELEGRAM_API_HASH` с https://my.telegram.org. Никаких чужих ключей в комплекте нет. Сборочный скрипт откажется собирать клиент с API ID 0/пустым hash; секретные значения не выводятся.

Firebase по умолчанию выключен. Для рабочего FCM/Crashlytics нужны собственные сервисные конфигурации под новый пакет; они не входят в этот комплект. Не используйте чужой google-services.json.

### Шаг 5. Собрать APK

ARM64 — быстрее для первой проверки:

```bash
bash weexgram/build-local.sh "$PWD"
```

Две ARM ABI в одном APK:

```bash
bash weexgram/build-local.sh "$PWD" --all-abis
```

Скрипт запускает штатную задачу базы:

```bash
./gradlew :TMessagesProj_AppStandalone:assembleAfatStandalone -PngArm64Only
```

Внутри сборки используются штатные Android/Gradle этапы, включая aapt2 и D8. Заменять весь Telegram-форк однострочной ручной командой d8 нельзя: здесь JNI/CMake, Chaquopy, desugaring и несколько модулей.

По умолчанию выделяется до 6 GB Gradle heap, 2 workers, Kotlin выполняется in-process. Для своей машины можно задать `WEEX_GRADLE_JVMARGS` и `WEEX_WORKERS`; меньшая память не гарантирует успешную сборку.

### Шаг 6. Подписать и забрать результат

Результат успешной работы скрипта:

```text
WeexGram/weexgram-out/WeexGram.apk
WeexGram/weexgram-out/SHA256.txt
WeexGram/weexgram-out/badging.txt
```

Это **ожидаемые выходные файлы будущей локальной сборки**, не APK, якобы уже собранный в этом комплекте.

Если release-подпись задана четырьмя свойствами `RELEASE_STORE_FILE`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`, Gradle использует её. Иначе скрипт подписывает результат новым локальным development-ключом в `.weexgram-private/development.jks` с открытым тестовым паролем `android`. Он подходит только для разработки, не для публичного релиза. Сохраните свой production-ключ и не меняйте его между обновлениями.

Проверяются zipalign/signature; `apksigner verify` и badging выполняются скриптом. Пакет отличается от NimarkoGram: установка не переносит его аккаунты/данные и не требует удаления исходного приложения.

## 4. Сборка через GitHub Actions

После применения и коммита изменений в ваш собственный репозиторий workflow будет в `.github/workflows/weexgram-build.yml`.

1. Сохраните в GitHub Secrets: `TELEGRAM_API_ID`, `TELEGRAM_API_HASH`.
2. Создайте свой release keystore и сохраните Secrets: `WEEX_KEYSTORE_B64` (base64 файла без переносов), `WEEX_KEYSTORE_PASSWORD`, `WEEX_KEY_ALIAS`, `WEEX_KEY_PASSWORD`.
3. Откройте Actions → WeexGram ARM64 standalone → Run workflow.
4. После **успешной** сборки скачайте artifact `WeexGram-ARM64` с APK и хешем.

Workflow запускается вручную, без передачи секретов из pull request. Он устанавливает JDK 17, Python 3.11, SDK 36, NDK и CMake. Он подготовлен, **но здесь не был запущен**: репозиторий на вашем аккаунте и секреты мы не создавали.

## 5. Проверки перед реальным релизом

1. Полная сборка с SDK 36 и реальными native submodules; проверка подписи/пакета/версии APK.
2. Чистый первый запуск, вход в аккаунт, перезапуск, восстановление процесса и поворот экрана.
3. Оба сценария onboarding; отмена SAF; ошибка записи файла; ручная установка внешнего плагина. Native/external не должны открывать два плеера.
4. Музыка из чата, профиля, мини-плеера и LaunchActivity; play/pause, seek, конец очереди, смена трека/аккаунта, фоновые уведомления и гарнитура. Голосовые сообщения не заменяются музыкальным UI.
5. LRCLIB: opt-in/отказ, 404/429/503, потеря сети, несовпадающая длительность, instrumental/plain/synced, смена трека во время запроса. При закрытии шторки старые результаты не должны менять UI.
6. Blur на API 31+, отсутствие blur на API 24–30, FLAG_SECURE, экономия памяти, низкая производительность GPU. Реальный progressive blur и его снимок нужно визуально проверить на устройстве.
7. Material-тема светлая/тёмная, крупный системный шрифт, TalkBack и отключённые анимации.
8. Подтвердить лицензию/права на распространяемый legacy-плагин, сохранить GPL-исходники и NOTICE, заменить homepage User-Agent LRCLIB на адрес вашего опубликованного форка.
9. Отдельный аудит всех унаследованных сервисов, URL/обновлений и брендинга. Автоматическая проверка обновлений NimarkoGram отключена, но его ручные настройки/сервисы не удалены глобально. Не публикуйте этот стартовый патч как полностью проверенный приватный клиент.

## 6. Что уже проверено, а что нет

- Проверены изменения относительно зафиксированной базы и отсутствие whitespace-ошибок patch.
- Новые Kotlin-файлы проходят ограниченную компиляционную проверку с реальными Android API 36/Material/AndroidX API и минимальными заглушками Telegram API. Это НЕ компиляция всех изменённых Java-файлов NimarkoGram и не полная проверка совместимости с базой.
- Ресурсы проходят `aapt2 compile`; их полная линковка вместе со всеми ресурсами приложения не выполнялась.
- JVM-проверка LRC-парсера: дробные секунды, signed offset, несколько таймкодов в строке, сортировка, дубликаты, некорректные секунды.
- Полная сборка, подпись WeexGram APK, установка, авторизация и Android runtime **не проверены**. Отдельный standalone-APK не подменяется APK клавиатуры или исходным APK NimarkoGram.

Подробности файлов и контрольные суммы — `CHECKS.md`, `NOTICE.md`, `SHA256.json`.
