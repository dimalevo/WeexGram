# Что уже есть в базе NimarkoGram (коммит 0f1c6aa)

Проверено: список булевых флагов в `TMessagesProj/src/main/java/app/nimarkogram/messenger/AppConfig.java` (193 флага) и поиск по ключевым словам.
НЕ проверено: показан ли флаг в интерфейсе и работает ли он. Для каждого пункта нужно открыть экран и убедиться.

## Пункты спецификации, которые уже покрыты флагами базы
| Пункт спецификации | Флаг в AppConfig | Примечание |
|---|---|---|
| 22. Скрыть ID профиля | `showIDDC` | флаг показывает ID и DC; скрыть = выключить |
| 26. Отправка без подписи автора | `noAuthorship`, `forwardWithoutAuthor` | пересылка без подписи; проверить, совпадает ли поведение с описанием |
| 29. Отключить вибрацию | `disableVibration`, `vibrateInChats` | уже работает в `AndroidUtilities.vibrate` |
| 36. Капсула заголовка по центру | `centerTitle`, `centerChatTitle` | флаги центрирования |
| 39. Нижняя панель навигации | `showMainTabs`, `foldersAtBottom` | вкладки снизу |
| 40. Быстрое переключение папок | `folderSwipeEnabled`, `showMainTabsTitle` | свайп папок |
| 43. Скрыть истории | `hideStories`, `archiveStoriesFromUsers`, `hideArchivedStories` | |
| 42. Несколько аккаунтов | `showAccounts` | флаг показа аккаунтов |
| 44. Работа без сервисов Google | сборочный флаг `NIMARKO_FIREBASE_ENABLED=false` | уже в workflow |
| 15. Появление элементов, 13. Эффект нажатия | `isSpringAnimationEnabled`, `isMaterialAnimationEnabled`, `predictiveBack` | анимации пружинами и Material |
| 9. Фон чата | `customWallpapers` | свои обои |
| 8. Цвет пузырей | `replyCustomColors` (частично) | только цвет ответа, не пузырей |
| 33. Перемотка голосовых | `largerVoiceMessagesLayout` (частично) | перемотки нет, только размер |
| 25. Пароль на чаты | `askBiometricsToOpenChat`, `askBiometricsToOpenSavedMessages`, `askBiometricsToOpenArchive` | биометрия на чат и архив |
| 23. Блокировка приложения | `allowSystemPasscode` | проверить, есть ли экран пароля приложения |
| 34. Копирование кадра видео | `showCopyPhoto` | только фото |
| 19. Размер стикеров | `hideStickerTime`, `disablePremStickAnim` (частично) | размера нет |
| 46. Карточка профиля | `profileBackgroundColor`, `profileBackgroundEmoji`, `profileBirthDatePreview`, `profileBusinessPreview` | |
| 30. Отключить превью ссылок | не найдено | по ключевым словам «link» ничего нет |

## Не найдено в базе (нужно делать самим)
- 21. Скрыть номер телефона (локально).
- 16. Скругление аватарок.
- 27. Отмена и повтор ввода текста.
- 31–32. Шумоподавление и улучшение голосовых.
- 41. Перевод сообщений и целых чатов.
- 45. Избранное в быстром меню.
- 10. Автоматическая ночная тема по расписанию.
- 5. Набор иконок приложения (есть `showPencilIcon` и ряд иконок, но не набор).
- Акцент «Expressive»/Monet в настройках: флаги анимации есть, выбора палитры в базе не найдено.

## Вывод
Из 50 пунктов спецификации около 20 уже есть в базе в виде флагов. Для них нужна только строка в экране WeexGram, которая пишет тот же флаг. Остальные 30 — новая работа.
