#!/usr/bin/env python3
"""Apply WeexGram 0.1 to the exact public NimarkoGram base; never touches private configuration."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

BASE = '0f1c6aa243d8509339f528f35887b6d91d051a03'
kit = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    raise SystemExit('Usage: python3 apply.py /path/to/NimarkoGram')
repo = Path(sys.argv[1]).resolve()
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()
if git('rev-parse', 'HEAD') != BASE:
    raise SystemExit('Wrong base commit. Checkout ' + BASE + ' first.')
if git('status', '--porcelain'):
    raise SystemExit('Working tree is not clean. Commit/stash your changes; the installer will not overwrite them.')
manifest = json.loads((kit/'SHA256.json').read_text())
for name, expected in manifest.items():
    actual = hashlib.sha256((kit/name).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit('Kit checksum mismatch: ' + name)
files = [p for p in (kit/'overlay').rglob('*') if p.is_file()]
for source in files:
    if (repo/source.relative_to(kit/'overlay')).exists():
        raise SystemExit('Overlay path already exists: ' + str(source.relative_to(kit/'overlay')))
subprocess.run(['git', '-C', str(repo), 'apply', '--check', str(kit/'nimarkogram.patch')], check=True)
subprocess.run(['git', '-C', str(repo), 'apply', str(kit/'nimarkogram.patch')], check=True)
for source in files:
    target = repo/source.relative_to(kit/'overlay')
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
print('WeexGram applied. Configure your own private.properties, then run build-local.sh.')
print('This installer does not build an APK, install a plugin or contact Telegram.')
