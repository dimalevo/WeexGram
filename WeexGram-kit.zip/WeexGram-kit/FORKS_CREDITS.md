# Источники функций WeexGram

WeexGram объединяет функции из перечисленных ниже открытых клиентов Telegram.
Код берётся только из проектов с лицензией, совместимой с GPL-2.0 (лицензия NimarkoGram).
Проекты под GPL-3.0 в WeexGram не включаются. Ссылки и лицензии проверены 31.10.2026.

| Проект | Ссылка | Лицензия | Статус | Что берём |
|---|---|---|---|---|
| NimarkoGram | https://github.com/Ettacent/NimarkoGram | GPL-2.0 | основа | основа клиента |
| Nekogram | https://github.com/Nekogram/Nekogram | GPL-2.0 | активный | настройки, интерфейс, поведение |
| exteraGram | https://github.com/exteraSquad/exteraGram | GPL-2.0 | архив (с 28.01.2026, только чтение) | интерфейс, навигация |
| OwlGram | https://github.com/OwlGramDev/OwlGram | GPL-2.0 | - | настройки интерфейса |
| Telegram-FOSS | https://github.com/Telegram-FOSS-Team/Telegram-FOSS | GPL-2.0 | - | приватность, отсутствие сервисов Google |
| InuGram | https://github.com/teidesu/inugram | MIT | активный | отдельные патчи |
| exteraless | https://github.com/exteraless/exteraless | GPL-3.0 | активный | только идеи, код не копируем: полоса «пилюль», иконпаки, разрешения плагинов |
| forkgram (feedelphix/telegram_foss_fork) | https://github.com/feedelphix/telegram_foss_fork | GPL-2.0 | - | функции из Forkgram и Nekogram |

Исключены из-за лицензии GPL-3.0 (код не копируется): AyuGram Desktop, freshGram, SereinGram, Auto-Forwarder, exteraless. Идеи из них реализуются заново.
Исключено по решению пользователя: обход Premium и рекламы.

WeexGram распространяется под GPL-2.0. Авторы всех перечисленных проектов указаны выше.
Конкретный код, портированный из каждого проекта, будет отмечен в `FEATURES_SOURCES.md`.
